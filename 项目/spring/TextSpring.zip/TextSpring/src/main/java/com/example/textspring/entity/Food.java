package com.example.textspring.entity;

import lombok.Data;

import java.sql.Blob;

@Data
public class Food {
    private Integer food_id;
    private String food_name;
    private Blob food_picture;
    private Double food_price;
    private Integer food_rest;
    private String food_type;
}

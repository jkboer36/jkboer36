package com.example.textspring.mapper;

import com.example.textspring.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    //查询满足条件的某一页用户
    @Select("select * from user where user_name like concat(\"%\",#{username},\"%\") limit #{pagenum},#{pagesize}")
    List<User> selectPageWithParam(Integer pagenum, Integer pagesize, String username);

    //查询满足条件的所有用户数
    @Select("select count(*) from user where user_name like concat(\"%\",#{username},\"%\")")
    int selectTotalWithParam(String username);

}

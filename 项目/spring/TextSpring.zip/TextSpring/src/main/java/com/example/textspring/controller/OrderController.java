package com.example.textspring.controller;

import com.example.textspring.service.OrderService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/searchorderAll")
    public Page searchorderAll(@RequestParam Integer pageNum, @RequestParam Integer pageSize)
    {
        return orderService.selectAll(pageNum,pageSize);
    }

    @GetMapping("/searchorderU")
    public Page searchorderU(@RequestParam Integer pageNum, @RequestParam Integer pageSize,@RequestParam Integer userid)
    {
        return orderService.selectByUserid(pageNum,pageSize,userid);
    }

    @GetMapping("/searchorderW")
    public Page searchorderW(@RequestParam Integer pageNum, @RequestParam Integer pageSize,@RequestParam Integer orderstate)
    {
        return orderService.selectByOrderState(pageNum,pageSize,orderstate);
    }
}

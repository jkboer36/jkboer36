package com.example.textspring.service.iml;

import com.example.textspring.entity.Orders;
import com.example.textspring.mapper.OrderMapper;
import com.example.textspring.service.OrderService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceIml implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Override
    public Page selectAll(Integer pagenum, Integer pagesize) {
        int startId = (pagenum - 1) * pagesize, size = pagesize;
        List<Orders> data=orderMapper.selectAll(startId,size);
        int total=orderMapper.selectTotal();
        Page page = new Page();
        page.setTotal(total);
        page.setData(data);
        return page;
    }

    @Override
    public Page selectByUserid(Integer pagenum, Integer pagesize, Integer userid) {
        int startId = (pagenum - 1) * pagesize, size = pagesize;
        List<Orders> data=orderMapper.selectByUserid(startId,size,userid);
        int total=orderMapper.selectTotalUser(userid);
        Page page = new Page();
        page.setTotal(total);
        page.setData(data);
        return page;
    }

    @Override
    public Page selectByOrderState(Integer pagenum, Integer pagesize, Integer orderstate) {
        int startId = (pagenum - 1) * pagesize, size = pagesize;
        List<Orders> data=orderMapper.selectByOrderState(startId,size,orderstate);
        int total=orderMapper.selectTotalState(orderstate);
        Page page = new Page();
        page.setTotal(total);
        page.setData(data);
        return page;
    }
}

package com.example.textspring.service.iml;

import com.example.textspring.entity.Food;
import com.example.textspring.mapper.FoodMapper;
import com.example.textspring.service.FoodService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class FoodServiceIml implements FoodService {

    @Autowired
    private FoodMapper foodMapper;

    @Override
    public Page searchfood(Integer pagenum, Integer pagesize, String foodname, String foodtype) {
        int startId = (pagenum - 1) * pagesize, size = pagesize;
        List<Food> data=foodMapper.selectPageWithParam(startId,size,foodname,foodtype);
        int total = foodMapper.selectTotalWithParam(foodname,foodtype);
        Page page = new Page();
        page.setTotal(total);
        page.setData(data);
        return page;
    }
}

package com.example.textspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(TextSpringApplication.class, args);
    }

}

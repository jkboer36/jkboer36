package com.example.textspring.service.iml;

import com.example.textspring.mapper.UserMapper;
import com.example.textspring.entity.User;
import com.example.textspring.service.UserService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class UserServiceIml implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public Page searchuser(Integer pagenum, Integer pagesize, String username) {
        int startId = (pagenum - 1) * pagesize, size = pagesize;
        List<User> data = userMapper.selectPageWithParam(startId,size,username);
        int total = userMapper.selectTotalWithParam(username);
        Page page = new Page();
        page.setTotal(total);
        page.setData(data);
        return page;
    }
}

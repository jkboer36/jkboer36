package com.example.textspring.controller;

import com.example.textspring.service.FoodService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/foods")
public class FoodController {

    @Autowired
    private FoodService foodService;

    @GetMapping("/searchfood")
    public Page searchfood(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam String foodname, @RequestParam String foodtype)
    {
        return foodService.searchfood(pageNum,pageSize,foodname,foodtype);
    }
}

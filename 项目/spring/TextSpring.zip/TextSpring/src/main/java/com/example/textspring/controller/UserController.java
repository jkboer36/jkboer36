package com.example.textspring.controller;

import com.example.textspring.service.UserService;
import com.example.textspring.utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/searchuser")
    public Page searchuser(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam String username)
    {
        return userService.searchuser(pageNum,pageSize,username);
    }


}

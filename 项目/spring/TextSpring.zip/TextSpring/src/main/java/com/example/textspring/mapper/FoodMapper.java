package com.example.textspring.mapper;

import com.example.textspring.entity.Food;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FoodMapper {

    //查询满足条件的商品
    @Select("select * from food where food_name like concat(\"%\",#{foodname},\"%\") and food_type like concat(\"%\",#{foodtype},\"%\") limit #{pagenum},#{pagesize}")
    List<Food> selectPageWithParam(Integer pagenum, Integer pagesize, String foodname,String foodtype);

    //查询满足条件的所有用户数
    @Select("select count(*) from food where food_name like concat(\"%\",#{foodname},\"%\") and food_type like concat(\"%\",#{foodtype},\"%\")")
    int selectTotalWithParam(String foodname,String foodtype);
}

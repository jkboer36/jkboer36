package com.example.textspring.service;

import com.example.textspring.utils.Page;
import org.springframework.stereotype.Service;

@Service
public interface UserService {

    public Page searchuser(Integer pagenum, Integer pagesize, String user_name);

}

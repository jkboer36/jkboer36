package com.example.textspring.service;

import com.example.textspring.utils.Page;
import org.springframework.stereotype.Service;

@Service
public interface OrderService {

    public Page selectAll(Integer pagenum, Integer pagesize);
    public Page selectByUserid(Integer pagenum, Integer pagesize,Integer userid);
    public Page selectByOrderState(Integer pagenum, Integer pagesize,Integer orderstate);
}

package com.example.textspring.mapper;

import com.example.textspring.entity.Orders;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface OrderMapper {

    //查询所有订单
    @Select("select * from orders limit #{pagenum},#{pagesize}")
    List<Orders> selectAll(Integer pagenum, Integer pagesize);

    @Select("select count(*) from orders")
    int  selectTotal();

    //查询用户订单
    @Select("select * from orders where user_id=#{userid} limit #{pagenum},#{pagesize}")
    List<Orders> selectByUserid(Integer pagenum, Integer pagesize,Integer userid);

    @Select("select count(*) from orders where user_id=#{userid}")
    int  selectTotalUser(Integer userid);

    //查询可接取订单
    @Select("select * from orders where order_state=#{orderstate} limit #{pagenum},#{pagesize}")
    List<Orders> selectByOrderState(Integer pagenum, Integer pagesize,Integer orderstate);

    @Select("select count(*) from orders where order_state=#{orderstate}")
    int  selectTotalState(Integer orderstate);

}

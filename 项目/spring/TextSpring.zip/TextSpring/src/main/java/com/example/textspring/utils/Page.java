package com.example.textspring.utils;

import lombok.Data;

@Data
public class Page {
    private Integer total;
    private Object data;
}

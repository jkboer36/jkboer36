package com.example.textspring.service;

import com.example.textspring.utils.Page;
import org.springframework.stereotype.Service;

@Service
public interface FoodService {
    public Page searchfood(Integer pagenum, Integer pagesize, String foodname, String foodtype);
}

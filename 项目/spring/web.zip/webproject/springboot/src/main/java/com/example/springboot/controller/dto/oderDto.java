package com.example.springboot.controller.dto;

public class oderDto {
    private String user_id;
    private String food_id;

}

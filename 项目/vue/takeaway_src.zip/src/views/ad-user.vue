<template>
  <el-container class="container" style="width: 100%; height: 100%">
    <el-header height="10%">
      <Header></Header>
    </el-header>
    <el-container>
      <el-aside width="200px">
        <Ad_aside></Ad_aside>
      </el-aside>
      <el-main>
            <Ad_user></Ad_user>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Header from "@/components/Header";
import Ad_aside from "@/components/Ad_aside";
import Ad_user from "@/components/Ad_user";

export default {
  name: "ad-user",
  components: {
    Header,
    Ad_aside,
    Ad_user,
  },
};
</script>

<style scoped>
.container .el-header {
  position: relative;
  background-color: bisque;
}

.container .el-aside {
  background: url("../assets/food.png");
}

</style>
<template>
  <div class="header">
    <div style="width: 15%">system logo</div>
    <div style="flex:1"></div>
    <div>
      <el-avatar :size="50" :fit="fill" :src="url" style="margin:20px 10px 10px 30px"/>
    </div>
  </div>
</template>

<script>
export default {
    name:"Header",
    data(){
        return{
            url:require("../assets/avatar1.png")
        }
    },
    methods:{
        search:function(){

        }
    }
};
</script>

<style scope>
.header {
  display: flex;
  height: 80px;
  line-height: 80px;
}
</style>
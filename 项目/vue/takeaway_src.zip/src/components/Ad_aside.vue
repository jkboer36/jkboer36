<template>
  <div>
      <el-menu default-active="1" text-color="#f2ecde" active-text-color="#f05654">
        <el-menu-item index="1">
          <el-icon :size="20"><User /></el-icon>
          <span>用户</span>
        </el-menu-item>
        <el-menu-item index="2">
          <el-icon :size="20"><Tickets /></el-icon>
          <span>订单</span>
        </el-menu-item>
        <el-menu-item index="3">
          <el-icon :size="20"><Bowl /></el-icon>
          <span>商品</span>
        </el-menu-item>
      </el-menu>
  </div>
</template>

<script>
export default {
  name: "Ad_aside",
  method: {}
};
</script>

<style>
.el-menu{
  background-color:rgba(255, 255, 255, 0);
}

.el-menu-item:hover{
  background-color: #ffa60084;
}

.el-menu-item{
  font-size: 25px;
  font-weight: bold;
  height: 200px;
}
</style>
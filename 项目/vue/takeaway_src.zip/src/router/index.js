import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'ad-user',
    component: () => import(/* webpackChunkName: "about" */ '../views/ad-user.vue')
  },
  {
    path: '/1',
    name: 'Ad-user',
    component: () => import(/* webpackChunkName: "about" */ '../components/Ad_user.vue')
  },
  {
    path: '/2',
    name: 'Ad-order',
    component: () => import(/* webpackChunkName: "about" */ '../components/Ad_order.vue')
  },
  {
    path: '/3',
    name: 'Ad-food',
    component: () => import(/* webpackChunkName: "about" */ '../components/Ad_food.vue')
  },
  {
    path: '/4',
    name: 'user',
    component: () => import(/* webpackChunkName: "about" */ '../components/User.vue')
  },
  {
    path: '/:catchAll(.*)',
    name: '/404',
    component: () => import(/* webpackChunkName: "about" */ '../views/404.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
